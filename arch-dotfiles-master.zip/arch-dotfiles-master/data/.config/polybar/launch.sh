#!/bin/bash

killall polybar

polybar primary &
polybar secondary &

